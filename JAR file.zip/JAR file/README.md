# Graphical-Based Robotics Programming Language

( The GRPL Tool as Desktop Application )

Version: 1.31

GNU GPLv3

==========================

MSEE student:    Ali M. Al-Bayaty

Thesis advisor:  Christopher Martinez, Ph.D.

University of New Haven

Fulbright Scholar, MSEE '14

==========================
