# Graphical-Based Robotics Programming Language

( GRPL Tool / RoboMind Simulator )

Version: 1.31

GNU GPL v3

==================================

MSEE student:	Ali M. Al-Bayaty

Thesis advisor:	Christopher Martinez, Ph.D.

University of New Haven

Fulbright Scholar, MSEE '14

==================================

+ RoboMind Simulator:	http://robomind.net/en/index.html

==================================
