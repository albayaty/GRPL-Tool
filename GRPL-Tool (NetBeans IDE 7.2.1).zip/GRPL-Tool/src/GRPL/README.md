# Graphical-Based Robotics Programming Language

( The GRPL Tool / Java Source Code / NetBeans IDE 7.2.1 )

Version: 1.31

GNU GPLv3

==========================

MSEE student:    Ali M. Al-Bayaty

Thesis advisor:  Christopher Martinez, Ph.D.

University of New Haven

Fulbright Scholar, MSEE '14

==========================

RoboMind Simulator:		http://robomind.net/en/index.html

==========================
